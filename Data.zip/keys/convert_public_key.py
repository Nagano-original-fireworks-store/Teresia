from cryptography.hazmat.primitives import serialization

# 读取PKCS#8格式的公钥
with open("./gen/temp_public_key.pem", "rb") as f:
    public_key = serialization.load_pem_public_key(f.read())

# 将公钥以PKCS#1格式保存
pkcs1_public_key = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.PKCS1,
)

with open("./gen/public_key.pem", "wb") as f:
    f.write(pkcs1_public_key)
